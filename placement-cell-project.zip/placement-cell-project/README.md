Placement Cell — Static Web Project
==================================

What you get
- A static single-page project that lists companies, roles and deadlines.
- Search, filter by upcoming deadlines, add new company (stored in localStorage), and download JSON.
- Project is pure HTML/CSS/JS — no build tools required.

How to use
1. Unzip the project and open `index.html` in your browser.
2. The app loads default data from `data/companies.json` on first run and then saves to localStorage.
3. Use "Add company" to add entries. Use "Download JSON" to export current data.

Files
- index.html — main page
- css/styles.css — styles
- js/script.js — client logic
- data/companies.json — sample data
- README.md — this file

Notes
- This is a starter project. If you want a server-backed version (Node/Express + MongoDB) tell me and I'll extend it.
- Dates in the sample data are ISO format (YYYY-MM-DD).
