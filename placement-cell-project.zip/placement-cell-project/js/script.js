// Simple client-side Placement Cell app — stores data in localStorage
const SAMPLE_PATH = 'data/companies.json';
let companies = [];

// DOM refs
const tableBody = document.querySelector('#company-table tbody');
const emptyMsg = document.getElementById('empty-msg');
const searchEl = document.getElementById('search');
const filterEl = document.getElementById('filter-deadline');
const addBtn = document.getElementById('add-btn');
const modal = document.getElementById('modal');
const form = document.getElementById('company-form');
const cancelBtn = document.getElementById('cancel');
const downloadBtn = document.getElementById('download-json');

function loadInitial(){
  const saved = localStorage.getItem('placement_companies_v1');
  if (saved){
    companies = JSON.parse(saved);
    render();
  } else {
    // fetch bundled sample JSON
    fetch(SAMPLE_PATH).then(r => r.json()).then(data => {
      companies = data;
      persist();
      render();
    }).catch(err => {
      console.error('Could not load sample data', err);
      companies = [];
      render();
    });
  }
}

function persist(){
  localStorage.setItem('placement_companies_v1', JSON.stringify(companies));
}

function render(){
  const q = searchEl.value.trim().toLowerCase();
  const filter = filterEl.value;
  const now = new Date();
  const in7 = new Date(); in7.setDate(now.getDate()+7);
  const in30 = new Date(); in30.setDate(now.getDate()+30);

  const rows = companies
    .filter(c => {
      if (!q) return true;
      return (c.company + ' ' + c.role).toLowerCase().includes(q);
    })
    .filter(c => {
      if (filter === 'all') return true;
      const d = new Date(c.deadline);
      if (filter === 'upcoming') return d <= in7;
      if (filter === 'month') return d <= in30;
      return true;
    })
    .sort((a,b) => new Date(a.deadline) - new Date(b.deadline));

  tableBody.innerHTML = '';
  if (rows.length === 0){
    emptyMsg.style.display = 'block';
  } else {
    emptyMsg.style.display = 'none';
  }
  for (const c of rows){
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(c.company)}</td>
      <td>${escapeHtml(c.role)}</td>
      <td>${escapeHtml(c.location || '-')}</td>
      <td>${formatDate(c.deadline)}</td>
      <td>${c.url ? '<a target="_blank" rel="noopener" href="'+escapeAttr(c.url)+'">Apply</a>' : '-'}</td>
    `;
    tableBody.appendChild(tr);
  }
}

function escapeHtml(s){ return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function escapeAttr(s){ return String(s || '').replace(/"/g,'&quot;'); }
function formatDate(d){
  if (!d) return '-';
  const dt = new Date(d);
  if (isNaN(dt)) return d;
  return dt.toLocaleDateString();
}

// UI events
searchEl.addEventListener('input', render);
filterEl.addEventListener('change', render);
addBtn.addEventListener('click', () => { modal.classList.remove('hidden'); });
cancelBtn.addEventListener('click', () => { modal.classList.add('hidden'); form.reset(); });

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const formData = new FormData(form);
  const newItem = {
    company: formData.get('company'),
    role: formData.get('role'),
    location: formData.get('location'),
    deadline: formData.get('deadline'),
    url: formData.get('url')
  };
  companies.push(newItem);
  persist();
  form.reset();
  modal.classList.add('hidden');
  render();
});

downloadBtn.addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(companies, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'placement_companies.json'; document.body.appendChild(a); a.click();
  a.remove(); URL.revokeObjectURL(url);
});

window.addEventListener('load', loadInitial);
